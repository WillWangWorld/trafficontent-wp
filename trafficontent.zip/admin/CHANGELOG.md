## [1.0.2] - 2025-06-07
### Added
- Auto-registration for WP site with token
- Welcome page with consent

### Fixed
- Activation redirect bug