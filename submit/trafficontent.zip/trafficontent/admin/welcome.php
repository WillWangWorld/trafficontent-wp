<?php
defined('ABSPATH') || exit;

// Submenu registration moved to settings.php. No need to add_submenu_page here.

function trafficontent_welcome_page() {
    // Optional: manual force cleanup via URL, with nonce check
    if (
        isset($_GET['force_disconnect']) &&
        current_user_can('manage_options') &&
        check_admin_referer('trafficontent_disconnect_nonce')
    ) {
        delete_option('trafficontent_channel_id');
        delete_option('trafficontent_consent_given');
    }
    ?>
    <div class="wrap trafficontent-welcome-wrap">
        <p class="trafficontent-welcome-header">Welcome to Trafficontent</p>
        <h1 class="trafficontent-welcome-title">Effortless Blog Content Automation for WordPress</h1>
        <div class="trafficontent-welcome-box">
        <?php
        // Show plugin logo securely using WordPress image handler
        if ($attachment_id = attachment_url_to_postid(plugins_url('assets/logo_l.png', dirname(__FILE__)))) {
            echo wp_kses_post(
                wp_get_attachment_image(
                    $attachment_id,
                    'medium',
                    false,
                    [
                        'class' => 'trafficontent-logo',
                        'alt' => esc_attr__('Trafficontent Logo', 'trafficontent')
                    ]
                )
            );
        }
        ?>
        <h2 class="trafficontent-welcome-subtitle">🚀 Welcome to Trafficontent!</h2>
            <p class="trafficontent-welcome-desc">Boost your organic traffic by filling your blog with automated endless content.</p>
            <form id="trafficontent-connect-form" class="trafficontent-connect-form" onsubmit="event.preventDefault(); connectTrafficontent();" method="post">
                <?php wp_nonce_field('trafficontent_connect_nonce_action', 'trafficontent_connect_nonce'); ?>
                <?php wp_nonce_field('trafficontent_disconnect_nonce'); ?>
                <label class="trafficontent-consent-label">
                    <input type="checkbox" name="trafficontent_agree" id="trafficontent_agree" class="trafficontent-consent-checkbox" required />
                    I consent to connect this site and share my admin email with Trafficontent.
                </label>
                <?php if (get_option('trafficontent_channel_id')): ?>
                    <button id="trafficontent-connect-btn" type="submit" class="button button-secondary trafficontent-connect-btn">
                        <span class="dashicons dashicons-update"></span>
                        <span class="btn-text">Reconnect Trafficontent</span>
                        <span class="spinner"></span>
                    </button>
                <?php else: ?>
                    <button id="trafficontent-connect-btn" type="submit" class="button button-primary trafficontent-connect-btn">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <span class="btn-text">Connect Trafficontent</span>
                        <span class="spinner"></span>
                    </button>
                <?php endif; ?>
            </form>
        </div>
        <div class="trafficontent-features">
            <div class="trafficontent-feature">
                <span class="dashicons dashicons-chart-line"></span>
                <h3>Smart SEO Insights</h3>
                <p>
                    Gain intelligent keyword suggestions and performance analytics for every post you publish.
                </p>
            </div>
            <div class="trafficontent-feature">
                <span class="dashicons dashicons-edit-page"></span>
                <h3>Automated Writing</h3>
                <p>
                    Let AI write high-quality blogs for you — just pick your topic and review.
                </p>
            </div>
            <div class="trafficontent-feature">
                <span class="dashicons dashicons-schedule"></span>
                <h3>Schedule & Forget</h3>
                <p>
                    Set up once and let Trafficontent publish on your behalf automatically.
                </p>
            </div>
            <div class="trafficontent-feature">
                <span class="dashicons dashicons-groups"></span>
                <h3>Organic Traffic</h3>
                <p>
                    Did you know that organic traffic is the most cost-effective growth channel?
                </p>
            </div>
            <div class="trafficontent-feature">
                <span class="dashicons dashicons-lightbulb"></span>
                <h3>Your Content Engine</h3>
                <p>
                    Research and explore the topic to craft engaging, relevant, and SEO-friendly content tailored to your audience.
                </p>
            </div>
            <div class="trafficontent-feature">
                <span class="dashicons dashicons-visibility"></span>
                <h3>Seamless Scheduling</h3>
                <p>
                    Save time, save money, schedule and automate your blog publishing workflow without ever leaving your WordPress dashboard.
                </p>
            </div>
        </div>
    </div>
    <?php
}

add_action('admin_init', function () {
    if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
        add_action('admin_head', function () {
            $screen = get_current_screen();
            if ($screen && $screen->id === 'trafficontent_page_trafficontent-welcome') {
                remove_all_actions('admin_notices');
            }
        });
    }
    if (
        isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST'
        && isset($_POST['trafficontent_agree'])
        && isset($_POST['trafficontent_connect_nonce'])
    ) {
        $raw_nonce = isset($_POST['trafficontent_connect_nonce']) ? sanitize_text_field(wp_unslash($_POST['trafficontent_connect_nonce'])) : '';
        // Ensure nonce is set and valid before proceeding
        if (!$raw_nonce || !wp_verify_nonce($raw_nonce, 'trafficontent_connect_nonce_action')) {
            return;
        }
        if (!current_user_can('manage_options')) return;

        // If receiving JSON (from JS), verify nonce from JSON body and only process required fields
        $body = json_decode(file_get_contents('php://input'), true);
        if ($body && is_array($body)) {
            $nonce = isset($body['nonce']) ? sanitize_text_field($body['nonce']) : '';
            if (!$nonce || !wp_verify_nonce($nonce, 'trafficontent_connect_nonce_action')) {
                wp_send_json_error(['message' => 'Invalid nonce'], 403);
                exit;
            }
        }

        update_option('trafficontent_consent_given', true);

        // Prevent duplicate registration if channel_id exists
        $channel_id = get_option('trafficontent_channel_id');
        if (!empty($channel_id)) {
            // Trafficontent: Channel ID already exists, skipping registration.
            wp_redirect(admin_url('admin.php?page=trafficontent-channels'));
            exit;
        }

// Registration now handled by JS fetch()

        // Show error message in admin UI with API failure message
        add_action('admin_notices', function () {
            echo '<div class="notice notice-error"><p><strong>Trafficontent:</strong> Please use the Connect button to register the site.</p></div>';
        });
    }
});
// Redirect to welcome/setup page after activation
register_activation_hook(__FILE__, function () {
    delete_option('trafficontent_channel_id');
    delete_option('trafficontent_consent_given');
    delete_option('trafficontent_do_activation_redirect');
    update_option('trafficontent_do_activation_redirect', wp_create_nonce('trafficontent_activation_redirect'));
    // Force UI cleanup flag for JS
    update_option('trafficontent_ui_reset_needed', true);
});

add_action('admin_init', function () {
    // UI cleanup after reactivation
    if (get_option('trafficontent_ui_reset_needed')) {
        delete_option('trafficontent_ui_reset_needed');
        add_action('admin_footer', function () {
            echo "<script>localStorage.removeItem('trafficontent_channel_synced');</script>";
        });
    }
    $activation_nonce = get_option('trafficontent_do_activation_redirect', false);
    if ($activation_nonce) {
        delete_option('trafficontent_do_activation_redirect');
        // Only redirect if not in bulk activation and nonce is valid
        $wpnonce = isset($_REQUEST['_wpnonce']) ? sanitize_text_field(wp_unslash($_REQUEST['_wpnonce'])) : '';
        if (!isset($_GET['activate-multi']) && $wpnonce && wp_verify_nonce($wpnonce, 'trafficontent_activation_redirect')) {
            wp_safe_redirect(admin_url('admin.php?page=trafficontent-welcome'));
            exit;
        }
    }
});

// Enqueue admin assets for the welcome page
function trafficontent_enqueue_admin_assets($hook) {
    if ($hook !== 'trafficontent_page_trafficontent-welcome') return;

    wp_enqueue_style('trafficontent-style', plugin_dir_url(__FILE__) . '../assets/style.css');
    wp_enqueue_script('trafficontent-script', plugin_dir_url(__FILE__) . '../assets/script.js', ['jquery'], null, true);

    $inline_script = "localStorage.removeItem('trafficontent_channel_synced');";
    wp_add_inline_script('trafficontent-script', $inline_script);
}
add_action('admin_enqueue_scripts', 'trafficontent_enqueue_admin_assets');

// Omit Token Only Login