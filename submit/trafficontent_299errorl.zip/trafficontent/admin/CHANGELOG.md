## [1.0.3] - 2025-06-23
### Fixed
- Removed inline JavaScript and CSS
- Escaped all dynamic output properly
- Sanitized and validated input data
- Disclosed external API usage in readme.txt
- Added proper contributor identity

## [1.0.2] - 2025-06-07
### Added
- Auto-registration for WP site with token
- Welcome page with consent

### Fixed
- Activation redirect bug