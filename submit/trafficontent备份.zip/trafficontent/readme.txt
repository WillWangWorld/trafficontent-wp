=== Trafficontent ===
Contributors: trafficontent
Tags: blog, ai, automation, shopify, SEO
Requires at least: 5.0
Tested up to: 6.8
Stable tag: 1.0.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI blog writer and auto-poster that connects to trafficontent.com to generate and post blogs automatically.

== Description ==
Trafficontent AutoPoster connects your site with Trafficontent's AI engine. Once connected, your dashboard appears right inside WP Admin.

== Installation ==
1. Upload plugin.
2. Activate.
3. Visit the "Trafficontent" menu.
4. Follow setup or use auto-generated token.

== Screenshots ==
1. Embedded dashboard view
2. Blog auto-post settings panel

== Frequently Asked Questions ==
= How does Trafficontent generate blogs? =
It connects with trafficontent.com API to use AI to generate, schedule, and post blog content.

== Changelog ==
= 1.0.2 =
Compatibility updates and improvements.